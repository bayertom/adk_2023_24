#include "sortpointsbyy.h"

sortPointsByY::sortPointsByY()
{

}
