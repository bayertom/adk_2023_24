#include "sortpointsbyx.h"

sortPointsByX::sortPointsByX()
{

}
